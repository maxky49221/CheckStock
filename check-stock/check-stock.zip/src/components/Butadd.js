const Butadd = ({inde},{c}) => {
    return ( 
        <button className="botton"> {inde} </button>
     );
}
 
export default Butadd;