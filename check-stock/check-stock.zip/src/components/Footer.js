const Footer = () => {
  return (
      <div>
    <footer class="bottom-footer">
      <p>Ratchanon</p>
    </footer>
    </div>
  );
};

export default Footer;
