const Nev = ({header}) => {
    return (
        <div className="header">
          <h1 className="text">{header}</h1>
        </div>
        );
    }
export default Nev ;